# Purpose Recovery Export Manifest

This export contains the complete maintainable source tree and documentation for the Purpose Recovery web project. Generated dependencies, build output, Git metadata, logs, and temporary files are excluded. Reinstall dependencies with `pnpm install --frozen-lockfile` and rebuild with `pnpm build`.

Included documentation:

- `docs/DEPLOYMENT.md` — environment variables, deployment, verification, and quarterly maintenance.
- `docs/MAINTENANCE.md` — source map, safe change workflow, and known export limitation.
- `docs/OUTREACH_CAMPAIGN_PLAN.md` — 90-day Douala and Bamenda community outreach and digital campaign strategy.
- `docs/contact_sources.md` — official contact URLs and verification notes.
- `docs/teen_challenge_implementation_guide.md` — recovery model implementation guide.

The homepage references Manus Storage assets. See `docs/DEPLOYMENT.md` for the four image identifiers that must be preserved or rehosted when moving to another platform.
