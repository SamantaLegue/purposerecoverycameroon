# Purpose Recovery: Douala and Bamenda Outreach Campaign Plan

## Executive recommendation

Run a **90-day two-city pilot** rather than launching a large public rehabilitation promise. The pilot should build trust, recruit a small circle of church and professional partners, test safe referral conversations, and collect only aggregate engagement data. Use Facebook and WhatsApp as the primary digital path. Add short radio conversations and in-person church or community sessions so the campaign reaches people with limited or inconsistent internet access.

Cameroon had 12.4 million internet users, 25.5 million cellular mobile connections, and 5.45 million social-media user identities at the start of 2025. Facebook was the broadest platform in the available country-level data, while Instagram’s reach was much smaller. These figures support a mobile-first, Facebook-led campaign with WhatsApp as the response channel rather than an Instagram-only launch [1].

UNICEF reports an outreach post in Bamenda and a logistics hub in Douala, while its Cameroon work emphasizes vulnerable children and child-protection systems. The campaign should therefore position Purpose Recovery as a respectful community referral and mentorship initiative, not as a replacement for established protection or clinical services [2]. A 2025 example from Bright Light Projects and CBC Radio Bamenda also shows the value of combining a youth program with radio education, dialogue, and strategic partnerships [3].

## Outcomes for the first 90 days

By the end of the pilot, the team should have a verified partner circle in both cities, a repeatable monthly information session, a tested referral protocol, and evidence about which messages generate safe conversations. A realistic target is five to eight confirmed organizational relationships, two small listening sessions in each city, twenty trained volunteers or church contacts, and twenty-five qualified partner or family conversations. These are planning targets, not promises of people served.

The campaign should not publish a target based on the number of youths “rescued.” That language can stigmatize young people and encourage unsafe intervention. Measure whether people can find appropriate support, understand emergency boundaries, and reach a qualified human being.

## Audiences and message discipline

The first audience is **trusted adults**: pastors, youth leaders, school staff, health workers, counselors, parents, and community organizers. They need a clear explanation of the three-phase recovery framework, the limits of volunteer care, and the next safe referral step.

The second audience is **young people and families**. They need dignity, hope, confidentiality boundaries, and a simple invitation to ask for guidance. Avoid asking them to disclose trauma publicly. Use private WhatsApp conversations only after explaining that WhatsApp is not an emergency service and that users should not send medical records or identity documents.

The third audience is **supporters and potential partners**. They need a concrete low-budget starting point: contribute a room, volunteer time, professional advice, transport, food, training, or a referral relationship. Avoid asking for a large facility before the safeguarding and operating model is ready.

The core message should be: **“A young person is more than the crisis you can see. Together, we can create a safe next step toward purpose, faith, skills, and belonging.”** In French, use: **« Un jeune est plus grand que la crise que l’on voit. Ensemble, créons une prochaine étape sûre vers la vocation, la foi, les compétences et l’appartenance. »**

## City-specific approach

### Douala

Douala should be the coordination and partner-development base because the founder is located there and the city has a dense network of churches, hospitals, schools, and community organizations. Begin with one church listening session and one professional roundtable. The goal is not to recruit residents immediately. The goal is to identify a safe referral chain for counseling, medical care, family mediation, education, and emergency escalation.

Digital content should use English and French captions, with short vertical videos that explain one practical idea at a time. Run modest Facebook promotion around Douala only after the team has a response plan for comments and WhatsApp messages. Use the website’s city filter and map to make the next step concrete, but tell users to verify current services before travel.

### Bamenda

Bamenda should use a partnership-led and radio-supported model. Start with a small church or community listening group, followed by a conversation with a counseling or mental-health provider and a local media partner. The Bright Light Projects and CBC Radio Bamenda example suggests that radio can support education, dialogue, and youth skills messaging alongside online content [3].

Avoid public storytelling that could expose young people or families affected by conflict, displacement, substance use, exploitation, or violence. Use general themes such as “how to respond when a young person stops coming home” and “how a church can refer safely.” When possible, publish short audio clips and WhatsApp-friendly image cards rather than assuming continuous video access.

## Channel plan

**WhatsApp** is the conversion channel. Keep two paths: one for partners and one for a young person or family seeking guidance. Use prefilled messages that ask for city, relationship to the situation, broad support type, and a safe contact time. Never request detailed case histories in the first public message.

**Facebook** is the discovery and community channel. Publish three times per week: one practical safeguarding or referral lesson, one hope-and-purpose message, and one partner or volunteer invitation. Use boosted posts only for content that the team can respond to within one working day. Do not boost graphic crisis stories or use fear-based language.

**Instagram** is a secondary visual channel. Repurpose the strongest Facebook content into subtitled reels, carousels, and simple quote cards. Avoid identifiable faces unless written consent is documented and the story is safe to publish. Prefer hands, rooms, notebooks, training moments, and anonymized illustrations.

**Radio and community dialogue** are trust channels. Prepare a 15-minute bilingual discussion outline for local radio or church gatherings. Include one safety boundary, one practical response, one local referral pathway, and one invitation to the website or WhatsApp line. Do not conduct live case management on air.

**Church and professional networks** are the accountability channel. Give each partner a one-page referral card that states what Purpose Recovery can do, what it cannot do, who handles emergencies, and how consent and confidentiality should work.

## 90-day execution calendar

| Period | Main objective | Actions | Evidence of progress |
| --- | --- | --- | --- |
| Days 1–15 | Prepare the response system | Confirm two city coordinators, recheck directory contacts, approve a safeguarding script, assign WhatsApp response hours, and prepare English/French content templates. | A named response rota, verified contacts, and approved message library. |
| Days 16–30 | Listen before promoting | Conduct one Douala listening session and one Bamenda listening session with trusted adults. Ask what young people and families can safely access, what language they prefer, and what referrals fail today. | Short anonymized learning memo and revised FAQ. |
| Days 31–45 | Recruit partners | Hold a Douala church/professional roundtable and a Bamenda church/radio/community roundtable. Invite counseling, health, school, child-protection, and skills-development representatives. | Five to eight organizations agree to verify their role and contact path. |
| Days 46–60 | Launch the public pilot | Publish three weekly posts, one bilingual WhatsApp card, one short audio or radio segment, and one partner-facing invitation. Start with organic distribution and a small, tightly targeted Facebook test. | Reach, saves, shares, qualified conversations, and response time. |
| Days 61–75 | Test referrals and training | Run a short volunteer orientation on boundaries, consent, active listening, emergency escalation, and referral documentation. Review anonymous scenarios rather than real case details. | Volunteers can pass a simple scenario-based safety check. |
| Days 76–90 | Review and decide | Compare city results, contact verification, message performance, and partner feedback. Keep, revise, or stop channels based on safety and usefulness, not vanity metrics. | A 90-day review with a decision on the next quarter. |

## Content system

Use four recurring content pillars. **Purpose and belonging** shows that recovery includes identity, skills, work, faith, and community. **Practical response** teaches adults what to do when a young person is missing, using substances, refusing school, or sleeping outside, while emphasizing professional referral. **Partner readiness** explains how churches, schools, counselors, and health workers can contribute safely. **Hope with boundaries** shares the vision while clearly stating that the project is not emergency medical care and cannot perform unsupervised detoxification.

A weekly rhythm can be simple: Tuesday for a practical bilingual carousel, Thursday for a short story or reflection without identifying a real client, and Saturday for a partner or referral action. Add one radio or in-person conversation every two weeks. Reuse each core idea as a Facebook post, an Instagram caption, a WhatsApp image card, and a spoken radio outline.

## Low-budget pilot budget

Keep the first test within a budget the founder can explain transparently. A suggested range is **150,000–350,000 XAF for 90 days**, excluding professional care and transport that partners may provide separately. Use the lower end for data bundles, simple design and printing, volunteer refreshments, and one modest Facebook test. Use the upper end only if the team has confirmed radio time, transport, and response capacity.

Do not spend on advertising before a human response rota exists. A campaign that increases vulnerable messages without a safe reply process creates risk rather than impact.

## Measurement and learning

Track aggregate website events already implemented: language switches, directory searches, WhatsApp shares, and referral-form preparations. Add a simple monthly spreadsheet for city, channel, content theme, response time, whether a qualified partner was reached, and whether a contact required re-verification. Do not store names, phone numbers, detailed case histories, or medical information in the campaign dashboard.

The most important indicators are qualified partner conversations, successful referral handoffs, contact accuracy, response time, volunteer readiness, and the percentage of users who can find the emergency disclaimer. Reach, impressions, and follower count are secondary indicators.

## Safeguarding rules for public campaigning

Do not photograph or identify a young person in recovery without informed, documented consent from the appropriate person and a separate decision that publication is safe. Do not use before-and-after images, crime descriptions, sexual exploitation details, or sensational substance-use language to increase engagement. Do not promise transformation timelines, guaranteed healing, admission, shelter, or confidentiality beyond the systems the team can actually provide.

Moderate comments and remove requests for public case details. Move genuine requests to the private referral pathway, explain the limits of that pathway, and escalate emergencies to appropriate local services. Keep the public campaign focused on dignity, practical action, and safe connection.

## First seven actions

1. Appoint one Douala response lead and one Bamenda partnership lead.
2. Reconfirm every directory contact and record the date of verification.
3. Prepare six bilingual posts and two WhatsApp cards before any paid promotion.
4. Invite one counseling or health professional to review the public response script.
5. Schedule the first listening session in each city.
6. Approach a radio or community media partner in Bamenda with a 15-minute educational outline.
7. Review the first 30 days using safety, referral quality, and response time before increasing reach.

## References

[1]: https://datareportal.com/reports/digital-2025-cameroon "Digital 2025: Cameroon — DataReportal"
[2]: https://www.unicef.org/cameroon/about-us "About us — UNICEF Cameroon"
[3]: https://brightlightprojects.org/2025/08/27/bright-light-projects-and-cbc-radio-bamenda-launch-youth-empowerment-program-with-mou-signing/ "Bright Light Projects and CBC Radio Bamenda Launch Youth Empowerment Program with MOU Signing"
