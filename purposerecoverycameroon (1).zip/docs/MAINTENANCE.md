# Purpose Recovery: Maintainer Handoff

## What is included

The exported repository contains the React/Vite source, routing, styling, consent and privacy components, interactive directory map, bilingual referral flow, analytics helper, package lockfile, and build configuration. The original Teen Challenge implementation guide is copied into `docs/teen_challenge_implementation_guide.md`. Verified contact sources are copied into `docs/contact_sources.md`.

## Source map

| Area | File |
| --- | --- |
| Application shell and routes | `client/src/App.tsx` |
| Homepage and directory data | `client/src/pages/Home.tsx` |
| Referral form and FAQ | `client/src/pages/Referral.tsx` |
| Privacy notice | `client/src/pages/Privacy.tsx` |
| Consent banner | `client/src/components/ConsentBanner.tsx` |
| Google Maps wrapper | `client/src/components/Map.tsx` |
| Directory map markers | `client/src/components/PartnerMap.tsx` |
| Analytics event helper | `client/src/lib/analytics.ts` |
| Design system | `client/src/index.css` |
| Build scripts | `package.json`, `vite.config.ts`, `tsconfig.json` |

## Safe change workflow

Create a branch or timestamped backup before changing contact information, emergency guidance, consent behavior, referral text, or analytics. Make the smallest change possible, run `pnpm check`, run `pnpm build`, then test the changed flow on desktop and mobile. Recheck all French text when changing English copy. Re-verify directory sources before publishing.

## Export limitation

The repository references four Manus Storage images rather than carrying local originals. A maintainer moving the site to another host must either preserve those storage URLs or download and rehost the images with appropriate usage rights. This export intentionally excludes `node_modules`, `dist`, `.git`, logs, and other generated files; dependencies are reproducible from `pnpm-lock.yaml`.

## Campaign documents

Use `docs/OUTREACH_CAMPAIGN_PLAN.md` for the next 90-day Douala and Bamenda pilot. Use `docs/DEPLOYMENT.md` for environment configuration, deployment, verification, and quarterly maintenance.
