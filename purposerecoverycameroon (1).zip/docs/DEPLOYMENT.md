# Purpose Recovery: Deployment and Maintenance Guide

## 1. Project summary

Purpose Recovery is a React 19 and Vite web experience for churches and community organizations developing Christ-centered youth recovery and mentorship programs. It is a client-first application with Wouter routing, Tailwind CSS 4, Lucide icons, an optional Google Maps proxy integration, consent-gated Umami analytics, WhatsApp intake links, a bilingual homepage, a bilingual referral flow, and a privacy notice.

The current application routes are `/` for the homepage, `/referral` for the referral intake flow, and `/privacy` for the privacy notice. The referral flow prepares a WhatsApp message in the browser; it does not submit case data to a server.

## 2. Requirements

Use Node.js 22 or a compatible current LTS release and pnpm 10. The repository contains a `pnpm-lock.yaml`, so install dependencies with the lockfile rather than switching package managers.

```bash
pnpm install --frozen-lockfile
pnpm check
pnpm build
```

The production build creates `dist/public` for static assets and bundles the small Express entrypoint to `dist/index.js`. The included start command is:

```bash
pnpm start
```

For local development:

```bash
pnpm dev
```

The Vite development server listens on the host configured by the script and defaults to port 3000.

## 3. Environment configuration

Create a deployment environment file or configure these variables in the hosting platform. Do not commit secrets.

| Variable | Required for | Description |
| --- | --- | --- |
| `VITE_FRONTEND_FORGE_API_KEY` | Map | Key accepted by the configured Maps proxy. |
| `VITE_FRONTEND_FORGE_API_URL` | Map, optional | Override for the Maps proxy base URL. The code has a default proxy fallback. |
| `VITE_ANALYTICS_ENDPOINT` | Analytics, optional | Umami host endpoint. Analytics is loaded only after consent. |
| `VITE_ANALYTICS_WEBSITE_ID` | Analytics, optional | Umami website identifier. |
| `VITE_APP_ID` | OAuth helper, if used | Existing template variable. |
| `VITE_OAUTH_PORTAL_URL` | OAuth helper, if used | Existing template variable. |

If the analytics variables are absent, the website still works and no analytics script is injected. If the map key is unavailable, the directory cards remain usable; the map should be treated as an enhancement rather than the only referral path.

## 4. Deployment procedure

First, create a clean working copy and install with the lockfile. Run `pnpm check` and `pnpm build`. Then deploy the repository using the hosting provider’s Node/Vite deployment workflow. The runtime must serve the bundled `dist/index.js` and expose the configured port. After deployment, verify `/`, `/referral`, and `/privacy` directly rather than checking only the root page.

Before public release, configure the production Umami endpoint and website ID, confirm that the consent banner appears in a fresh browser profile, test both acceptance and decline paths, and confirm that the map proxy is available. Do not publish until emergency language and directory contacts have been rechecked.

## 5. Verification checklist

Check the following on desktop and mobile:

- English/French switching covers the homepage, emergency notice, directory labels, referral page, privacy notice, and WhatsApp messages.
- The consent banner is visible before consent, accepts and declines correctly, and does not block essential content.
- The directory search and city/category filters continue to work if the map script fails.
- Map markers open organization name, city, contact, and source link, with a reminder to verify before travel.
- The referral form validates required fields and prepares a WhatsApp message without automatically sending it.
- No analytics event contains names, phone numbers, free-text case details, or medical information.
- WhatsApp links contain editable, privacy-conscious text.
- External directory links open the official source pages.
- `pnpm check` and `pnpm build` pass without errors.

## 6. Updating content

Homepage copy and directory records are in `client/src/pages/Home.tsx`. Referral copy and referral FAQs are in `client/src/pages/Referral.tsx`. The privacy notice is in `client/src/pages/Privacy.tsx`. Consent behavior is in `client/src/components/ConsentBanner.tsx`. The map wrapper is in `client/src/components/PartnerMap.tsx`, while the shared map loader is in `client/src/components/Map.tsx`.

When changing a contact, update the source URL and the verification date in the project’s contact-source record. Keep the “verify current details” language. Do not publish a direct referral contact that has not been confirmed on an official organization page.

## 7. Quarterly maintenance

Every quarter, verify directory phone numbers, addresses, services, opening hours, emergency guidance, analytics configuration, consent copy, and French translations. Review event counts for language switches, directory searches, WhatsApp shares, and referral preparation without attempting to identify individuals. Remove or correct any partner that cannot confirm its current details.

## 8. External media

The homepage references four images stored through Manus storage: `purpose-recovery-hero_d3c82821.jpg`, `purpose-recovery-mentoring_a18b0fa7.jpg`, `purpose-recovery-morning_e92e5a83.jpg`, and `purpose-recovery-workshop_6c19b686.jpg`. The codebase contains the references, not local originals. Preserve the storage assets or replace the references with a hosting provider’s permanent URLs before moving the site outside the Manus environment.

## 9. Important safety boundary

Purpose Recovery is an information and referral surface. It is not presented as a detoxification clinic, emergency service, shelter, or medical provider. Any future backend must add a documented privacy policy, access controls, retention rules, and qualified safeguarding review before receiving sensitive case information.
