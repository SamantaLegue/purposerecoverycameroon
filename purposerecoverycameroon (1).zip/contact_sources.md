# Verified contact sources used in the partner directory

- Hôpital Laquintinie, Douala: https://hopitallaquintinie.cm/contacts — official contact page lists +237 688 824 844.
- Bonaberi Baptist Hospital, Douala: https://cbchealthservices.org/health-centers/bonaberi-health-centre/ — official CBC Health Services page lists hospital contact +237 676 978 217.
- UNICEF Cameroon contact / Douala Hub: https://www.unicef.org/cameroon/contact-us — official page lists Douala Hub address and country office telephone +237 2 22 50 54 12.
- FOMCAM contact, Bamenda: https://fomcam.org/contact/ — official contact page lists +237-677-819-025 and Street 01 Mulang, Bamenda.
- CBC Community Counseling Clinic: https://cbchealthservices.org/services/community-counselling-clinic/ — official page lists receptionist +237 677 279 295 and after-hours emergency hotline +237 674 110 862; it describes counseling, mediation, addiction support, and confidentiality.
- Nkwen Baptist Hospital, Bamenda: https://cbchealthservices.org/health-centers/north-west-region/nkwen-baptist-hospital/ — official CBC page lists +237 675 205 729 / +237 683 158 210 and Finance Junction, Bamenda.
- Living Vine Mental Health Care: https://livingvinerehabilitation.com/ — official site used for Bamenda-based rehabilitation contact; current directory listing uses +237 677 931 232 / +237 677 35 72 00 and instructs users to verify intake, safeguarding, and fees.

Emergency numbers in the site are presented as commonly published Cameroon numbers with explicit local verification language; they are not treated as guaranteed universal coverage.
