# Purpose Recovery — Design Direction

## Three possible directions

### Theme Name: Hearth & Horizon
Very Brief Intro: A warm, editorial nonprofit aesthetic that pairs deep forest tones with sunlit apricot and generous paper-like space. It feels grounded, hopeful, and human rather than institutional.
Probability: 0.07

### Theme Name: Field Notes
Very Brief Intro: A practical, documentary-inspired system built around charcoal, clay, and notebook textures, with modular cards that feel like a field guide for church leaders. It emphasizes action and trust.
Probability: 0.04

### Theme Name: Quiet Renewal
Very Brief Intro: A calm, contemplative direction with pale mineral backgrounds, muted blue-green accents, and restrained typography. It feels reflective and suitable for pastoral care resources.
Probability: 0.06

## Chosen Approach: Hearth & Horizon

### Design Movement
Contemporary editorial nonprofit design with soft brutalist structure: strong typographic moments, asymmetrical compositions, honest photography, and tactile paper textures.

### Core Principles
1. Hope should feel practical. Pair every inspirational statement with a concrete next step.
2. Dignity over drama. Use calm language and human-scale imagery rather than crisis imagery or savior narratives.
3. Warm structure. The site should feel organized enough for implementation while retaining spiritual warmth.
4. Room to breathe. Use generous whitespace, offset columns, and clear section breaks rather than dense dashboard patterns.

### Color Philosophy
The signature color is ember-apricot, a warm orange that signals movement, courage, and human energy. It sits against deep evergreen, which communicates steadiness and trust. Bone and oat neutrals keep the page tactile and editorial. Color should feel like lamplight on a worktable: hopeful, focused, and grounded.

### Layout Paradigm
Use an editorial, asymmetric flow: a left rail for chapter markers and a right content field, with occasional wide horizontal bands for the framework and calls to action. Hero composition uses a split between a bold statement and a tall photographic panel rather than a centered hero.

### Signature Elements
1. A small ember mark made from a four-point compass/spark symbol, used in the logo and chapter markers.
2. Handwritten-style micro labels paired with serif headlines, suggesting a field guide without becoming rustic.
3. Offset “field note” cards with thin rules, subtle grain, and small numbered steps.

### Interaction Philosophy
Interactions should reduce uncertainty. Buttons reveal the next step; accordions answer practical questions; tabs let leaders compare phases without losing context. Motion is brief and directional, like turning a page or moving along a path.

### Animation
Use 180–240ms ease-out transitions for buttons, tabs, and accordion panels. Add subtle rise-and-fade entrances for section blocks with 40–70ms staggered delays. Avoid parallax and continuous motion. Respect prefers-reduced-motion.

### Typography System
Use Fraunces for display headings and Source Sans 3 for body/UI. Headlines are compact, slightly expressive, and sentence case. Body text is 16–18px with generous line-height. Labels use uppercase Source Sans 3 with 0.12em tracking.

### Brand Essence
Purpose Recovery helps churches and community organizations turn a burden for young people into a safe, structured recovery program with a clear path from outreach to re-entry. Personality: grounded, courageous, invitational.

### Brand Voice
Headlines sound direct, warm, and quietly confident. CTAs are specific and non-salesy. Microcopy acknowledges complexity without losing hope.

Example lines:
- “Turn a burden into a place of belonging.”
- “Start with a room, a rhythm, and a few people who will stay.”

### Wordmark & Logo
The wordmark is set in a high-contrast serif with a custom ember-compass mark replacing the dot over the “i” in Purpose. The mark is a four-point spark inside an imperfect circle, symbolizing direction, light, and a safe center.

### Signature Brand Color
Ember Apricot — #E8894A. Use it sparingly for primary actions, step numbers, and the ember mark so it remains ownable and memorable.

## Content Guardrails

The website should be clear that this is an implementation framework inspired by Teen Challenge, not an official Teen Challenge website or affiliation. It should encourage organizations to seek clinical, safeguarding, legal, and local regulatory guidance before offering residential or substance-use treatment. It must not imply guaranteed outcomes or use fabricated testimonials.

## Page Plan

The primary page will include a sticky header, hero, “why this exists” story, three-phase framework, implementation roadmap, daily rhythm, launch checklist, safety/ethics note, and a practical call-to-action section. The page will include one functional interactive element: a phase selector that updates the content panel and an expandable FAQ/checklist area.
