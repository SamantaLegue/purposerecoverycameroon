# Research findings for Douala and Bamenda outreach planning

DataReportal’s Digital 2025 Cameroon report states that Cameroon had 25.5 million cellular mobile connections, 12.4 million internet users, and 5.45 million social-media user identities at the beginning of 2025. It reports Facebook ad reach at 5.45 million and Instagram ad reach at 600,000. These figures support a mobile-first strategy with Facebook as the broadest paid and organic social channel, while Instagram is better used selectively for visual storytelling. The report also cautions that platform figures are estimates and are regularly revised.

UNICEF Cameroon’s current “About us” page states that UNICEF has an outreach post in Bamenda and a logistics hub in Douala. Its public site also links to Cameroon social channels including Facebook, X, LinkedIn, and Instagram. This supports a safeguarding-first partnership model in which the project maps referrals and seeks introductions through established child-protection actors rather than presenting itself as an emergency service.

Bright Light Projects reports that it and CBC Radio Bamenda launched a youth empowerment program through a memorandum of understanding in August 2025. The article describes radio as a platform for education, dialogue, engagement, youth skills development, community participation, and strategic partnerships. This supports using local radio and community dialogue as complements to social media, particularly for Bamenda audiences who may have uneven internet access.

The campaign plan should therefore use a two-city pilot, mobile-first landing pages, WhatsApp as the conversion path, Facebook as the broadest discovery channel, Instagram for carefully consented stories, and radio/community partners for reach and trust. The project must avoid identifying young people in public content, avoid promises of treatment or emergency response, and measure aggregate engagement rather than sensitive case details.

## Sources

[1]: https://datareportal.com/reports/digital-2025-cameroon "Digital 2025: Cameroon — DataReportal"
[2]: https://www.unicef.org/cameroon/about-us "About us — UNICEF Cameroon"
[3]: https://brightlightprojects.org/2025/08/27/bright-light-projects-and-cbc-radio-bamenda-launch-youth-empowerment-program-with-mou-signing/ "Bright Light Projects and CBC Radio Bamenda Launch Youth Empowerment Program with MOU Signing"
