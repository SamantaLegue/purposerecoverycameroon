type AnalyticsValue = string | number | boolean;
type AnalyticsData = Record<string, AnalyticsValue>;

declare global {
  interface Window {
    umami?: { track: (eventName: string, data?: AnalyticsData) => void };
  }
}

export function trackEvent(eventName: string, data?: AnalyticsData) {
  if (typeof window !== "undefined" && window.umami) {
    window.umami.track(eventName, data);
  }
}

export {};
