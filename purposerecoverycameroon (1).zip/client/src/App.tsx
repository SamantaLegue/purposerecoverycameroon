import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import Referral from "./pages/Referral";
import Privacy from "./pages/Privacy";
import ConsentBanner from "./components/ConsentBanner";
import { Route, Router, Switch } from "wouter";

/** Hearth & Horizon direction: warm editorial nonprofit design, deep evergreen + ember apricot, asymmetrical field-guide layout. */
export default function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          <ConsentBanner />
          <Router base={import.meta.env.BASE_URL}>
            <Switch>
              <Route path="/privacy" component={Privacy} />
              <Route path="/referral" component={Referral} />
              <Route path="/" component={Home} />
            </Switch>
          </Router>
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}
