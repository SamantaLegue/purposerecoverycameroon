import { useEffect, useState } from "react";
import { Check, X } from "lucide-react";

const CONSENT_KEY = "purpose-recovery-analytics-consent";
const ANALYTICS_SCRIPT_ID = "purpose-recovery-analytics";

type Language = "en" | "fr";

function enableAnalytics() {
  if (document.getElementById(ANALYTICS_SCRIPT_ID)) return;
  const endpoint = import.meta.env.VITE_ANALYTICS_ENDPOINT;
  const websiteId = import.meta.env.VITE_ANALYTICS_WEBSITE_ID;
  if (!endpoint || endpoint.includes("%VITE_") || !websiteId || websiteId.includes("%VITE_")) return;
  const script = document.createElement("script");
  script.id = ANALYTICS_SCRIPT_ID;
  script.defer = true;
  script.src = `${endpoint}/umami`;
  script.dataset.websiteId = websiteId;
  document.body.appendChild(script);
}

export default function ConsentBanner() {
  const [visible, setVisible] = useState(false);
  const [language, setLanguage] = useState<Language>("en");

  useEffect(() => {
    const saved = window.localStorage.getItem(CONSENT_KEY);
    if (saved === "accepted") enableAnalytics();
    if (!saved) setVisible(true);
  }, []);

  const accept = () => {
    window.localStorage.setItem(CONSENT_KEY, "accepted");
    enableAnalytics();
    setVisible(false);
  };

  const decline = () => {
    window.localStorage.setItem(CONSENT_KEY, "declined");
    setVisible(false);
  };

  if (!visible) return null;
  const isFrench = language === "fr";
  return <aside className="consent-banner" aria-label={isFrench ? "Consentement à la confidentialité" : "Privacy consent"}><div className="consent-copy"><div className="consent-kicker">{isFrench ? "Confidentialité" : "Privacy"}</div><p>{isFrench ? "Nous utilisons uniquement des mesures anonymisées pour comprendre l’utilisation du site et améliorer l’aide proposée. Les formulaires, messages WhatsApp et informations sensibles ne sont pas envoyés aux statistiques." : "We use privacy-conscious, aggregated analytics to understand site engagement and improve support. Form contents, WhatsApp messages, and sensitive information are not sent to analytics."}</p><a href="/privacy" className="consent-link">{isFrench ? "Lire la notice de confidentialité" : "Read the privacy notice"}</a></div><div className="consent-actions"><div className="language-toggle" role="group" aria-label="Consent banner language"><button className={!isFrench ? "active" : ""} onClick={() => setLanguage("en")}>English</button><button className={isFrench ? "active" : ""} onClick={() => setLanguage("fr")}>Français</button></div><div className="consent-buttons"><button className="button button-soft consent-decline" onClick={decline}><X size={15} /> {isFrench ? "Refuser les mesures" : "Decline analytics"}</button><button className="button button-apricot" onClick={accept}><Check size={15} /> {isFrench ? "Accepter les mesures" : "Accept analytics"}</button></div></div></aside>;
}
