import { useEffect, useRef } from "react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";

export type PartnerMapEntry = { city: string; name: string; contact: string; url: string; lat: number; lng: number };

const esc = (value: string) =>
  value.replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c] as string);

const safeUrl = (value: string) => (/^https?:\/\//i.test(value) ? value : "#");

/** OpenStreetMap + Leaflet: works on any static host, no API key or proxy required. */
export default function PartnerMap({ entries, language }: { entries: PartnerMapEntry[]; language: "en" | "fr" }) {
  const containerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<L.Map | null>(null);
  const layerRef = useRef<L.LayerGroup | null>(null);

  useEffect(() => {
    if (!containerRef.current || mapRef.current) return;
    const map = L.map(containerRef.current, { scrollWheelZoom: false }).setView([4.08, 9.72], 11);
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      maxZoom: 19,
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
    }).addTo(map);
    layerRef.current = L.layerGroup().addTo(map);
    mapRef.current = map;
    return () => {
      map.remove();
      mapRef.current = null;
      layerRef.current = null;
    };
  }, []);

  useEffect(() => {
    const map = mapRef.current;
    const layer = layerRef.current;
    if (!map || !layer) return;
    layer.clearLayers();
    const verify = language === "fr" ? "Vérifier les informations" : "Verify current details";
    entries.forEach(entry => {
      L.circleMarker([entry.lat, entry.lng], {
        radius: 9,
        color: "#173b35",
        weight: 2,
        fillColor: "#e8894a",
        fillOpacity: 0.9,
      })
        .bindPopup(
          `<strong>${esc(entry.name)}</strong><br /><span>${esc(entry.city)}</span><br /><span>${esc(entry.contact)}</span><br /><a href="${esc(safeUrl(entry.url))}" target="_blank" rel="noreferrer">${verify}</a>`
        )
        .addTo(layer);
    });
    if (entries.length > 1) {
      map.fitBounds(L.latLngBounds(entries.map(e => [e.lat, e.lng] as [number, number])), { padding: [40, 40], maxZoom: 12 });
    }
  }, [entries, language]);

  return (
    <div className="partner-map-wrap">
      <div ref={containerRef} className="partner-map" role="region" aria-label={language === "fr" ? "Carte des partenaires" : "Partner map"} />
      <div className="map-note">
        {language === "fr"
          ? "Les marqueurs indiquent des emplacements publics ou des points de ville approximatifs. Vérifiez l’adresse avant de vous déplacer."
          : "Markers show public locations or approximate city points. Verify the address before travelling."}
      </div>
    </div>
  );
}
