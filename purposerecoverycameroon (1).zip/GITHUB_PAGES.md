# Publish Purpose Recovery with GitHub Pages

## Recommended repository name

Create a new public GitHub repository named:

```text
purposerecoverycameroon
```

The resulting free website URL will be:

```text
https://YOUR-GITHUB-USERNAME.github.io/purposerecoverycameroon/
```

Replace `YOUR-GITHUB-USERNAME` with the actual GitHub username. The repository name and the `VITE_BASE_PATH` value in `.github/workflows/deploy-pages.yml` must match.

## Upload the project

From this project directory:

```bash
git init -b main
git add .
git commit -m "Prepare Purpose Recovery for GitHub Pages"
git remote add origin https://github.com/YOUR-GITHUB-USERNAME/purposerecoverycameroon.git
git push -u origin main
```

Do not commit `.env` files, passwords, API keys, or private service credentials.

## Enable Pages

In GitHub, open the repository and go to **Settings → Pages**. Under **Build and deployment**, select **GitHub Actions** as the source. The included workflow at `.github/workflows/deploy-pages.yml` will install dependencies, run the TypeScript check, build the site, create a single-page-app `404.html` fallback, and deploy `dist/public`.

After the workflow completes, GitHub will show the Pages URL under **Settings → Pages** and in the workflow deployment environment.

## If you choose another repository name

Change both values so they match. For example, for `purpose-recovery-cameroon`, change the workflow to:

```yaml
env:
  VITE_BASE_PATH: /purpose-recovery-cameroon/
```

The website URL will then be:

```text
https://YOUR-GITHUB-USERNAME.github.io/purpose-recovery-cameroon/
```

## Known limitation

The site’s partner map uses the configured Maps proxy and may not work on GitHub Pages without a public frontend map configuration. The directory cards, search, referral flow, and WhatsApp links remain available. The four brand images are hosted at public CDN URLs so the repository does not contain oversized binary files.

## Update: partner map

The partner map now uses OpenStreetMap and Leaflet, so it works on GitHub Pages with no API key or Maps proxy. The old Google Maps component (`client/src/components/Map.tsx`) is no longer used by the site.

## Update: About section

A bilingual (English/French) "Why I started" About section was added to the homepage, with an "About" link in the main navigation. Edit the text in `client/src/pages/Home.tsx`.
